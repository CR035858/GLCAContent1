package com.gl.q4;

import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {

		boolean loopStatus= true;
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Insert size of queue:");

		Queue queue = new Queue(sc.nextInt());

		while(loopStatus) {
			
			System.out.println("Select appropriate option:");
			System.out.println("1. Enqueue\n"
					+  "2. Dequeue\n"
					+  "3. IsFront\n"
					+  "4. IsEmpty\n"
					+  "5. IsFull\n"
					+  "6. Display\n"
					+  "7. Exit");

			int choice = sc.nextInt();

			switch(choice) {
			case 1:{
				
				// enqueue some elements
				System.out.println("Enter value to enqueue");
				queue.enqueue(sc.nextInt());
				
				break;
			}

			case 2:{
				
				// dequeue an element
				queue.dequeue();
				
				break;
			}

			case 3:{
				
				// peek at the front element
				System.out.println("Front element: " + queue.peekFront());
				
				break;
			}

			case 4:{
				System.out.println("Queue is empty = "+queue.isEmpty());
				break;
			}

			case 5:{
				
				System.out.println("Queue is Full = "+queue.isFull());
				break;
			}

			case 6:{
				queue.display();
				break;
			}
			
			case 7:{
				System.out.println("Exited successfully");
				loopStatus = false;
				break;
			}

			default:{
				System.out.println("Enter valid option");
				break;
			}
			}
		}
	}
}
