package com.gl.q4;

public class Queue {
	private int[] arr;  // array to store queue elements
	private int front;  // index of the front element
	private int rear;   // index of the rear element
	private int capacity;   // maximum capacity of the queue

	// constructor to initialize the queue
	public Queue(int size) {
		arr = new int[size];
		front = -1;
		rear = -1;
		capacity = size;
	}

	// method to check if the queue is empty
	public boolean isEmpty() {
		return front == -1;
	}

	// method to check if the queue is full
	public boolean isFull() {
		return rear == capacity - 1;
	}

	// method to add an element to the queue (enqueue)
	public void enqueue(int element) {
		if (isFull()) {
			System.out.println("Queue overflow");
			return;
		}
		if (front == -1) {
			front = 0;
		}
		rear++;
		arr[rear] = element;
		System.out.println(element + " enqueued to queue");
	}

	// method to remove an element from the queue (dequeue)
	public int dequeue() {
		if (isEmpty()) {
			System.out.println("Queue underflow");
			return -1;
		}
		int element = arr[front];
		if (front >= rear) {
			front = -1;
			rear = -1;
		} else {
			front++;
		}
		System.out.println(element + " dequeued from queue");
		return element;
	}

	// method to return the front element of the queue (peekFront)
	public int peekFront() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
			return -1;
		}
		return arr[front];
	}

	// method to display the contents of the queue
	public void display() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
			return;
		}
		System.out.println("Queue elements:");
		for (int i = front; i <= rear; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}
}
