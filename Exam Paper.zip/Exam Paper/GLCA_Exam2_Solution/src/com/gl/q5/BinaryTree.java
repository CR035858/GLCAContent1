package com.gl.q5;

class Node {
    int data;
    Node left, right;
 
    public Node(int item) {
        data = item;
        left = right = null;
    }
}
 
public class BinaryTree {
    Node root;
 
    /* Recursive function to calculate height of given binary tree */
    int height(Node node) {
        if (node == null)
            return 0;
        else {
            int leftHeight = height(node.left);
            int rightHeight = height(node.right);
 
            if (leftHeight > rightHeight)
                return (leftHeight + 1);
            else
                return (rightHeight + 1);
        }
    }
 
    public static void main(String args[]) {
        BinaryTree tree = new BinaryTree();
 
        /* Constructed binary tree is:
              1
            /   \
           2     3
          / \   / \
         4   5 6   7
        */
        tree.root = new Node(10);
        tree.root.left = new Node(7);
        tree.root.right = new Node(21);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(8);
        tree.root.right.left = new Node(16);
        tree.root.right.right = new Node(71);
 
        System.out.println("Height of tree is : " + tree.height(tree.root));
    }
}
