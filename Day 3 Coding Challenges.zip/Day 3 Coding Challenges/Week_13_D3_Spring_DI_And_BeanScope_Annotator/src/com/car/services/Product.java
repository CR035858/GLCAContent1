package com.car.services;

public class Product {

	String name;
	int price;
	
	public Product() {

	}

	public Product(String name, int price) {
		this.name = name;
		this.price = price;
	}
}
