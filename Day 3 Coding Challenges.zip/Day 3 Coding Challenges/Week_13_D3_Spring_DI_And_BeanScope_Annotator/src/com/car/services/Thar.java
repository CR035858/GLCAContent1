package com.car.services;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.car.interfaces.Car;

@Component
public class Thar implements Car {

	private String carName = "Thar";
	private float length = 5.0f;
	private float width = 1.5f;
	private float height = 2.5f;

	private int groundClearence = 210;
	
	@Value("${thar.price}")
	private long finalPrice = 2300000L;

	public RandomAccessory randomproduct;

	public long getFinalPrice() {
		return finalPrice;
	}

	public void setFinalPrice(long finalPrice) {
		this.finalPrice = finalPrice;
	}

	@Override
	public String getSpecs() {

		return "Car Model\t: "+carName+"\nLxWxH\t\t: "+length+" x "+width+" x "+height+" (m)\nGroundClearence\t: "+groundClearence+" (mm)";
	}

	@Override
	public String getPrice() {

		return "Final Price\t: "+finalPrice;
	}

	@Override
	public String deliveryDate() {
		return "Delivery on\t: "+LocalDate.now().plusDays(90)+" (If Ordered Now)";
	}

	@Override
	public String getAccessory() {

		return randomproduct.getFreeAccessory();
	}

	// 2. (a) setter Injection 
	// this will automatically wire to the required dependency
	@Autowired
	public void setAccessory(RandomAccessory randomproduct) {
		this.randomproduct = randomproduct;
	}


	// 2. (b) setter injection. 
	// when using qualifier for random product, need to specify as shown(for constructor also). else not needed
//	@Autowired
//	public void setAccessory(@Qualifier("randomGiftAccessory") RandomAccessory randomproduct) {
//		this.randomproduct = randomproduct;
//	}

}
