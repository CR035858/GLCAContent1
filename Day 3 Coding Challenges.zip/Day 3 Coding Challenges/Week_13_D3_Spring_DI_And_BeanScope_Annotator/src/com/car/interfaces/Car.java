package com.car.interfaces;

public interface Car {

	public String getSpecs();
	public String getPrice();
	public String deliveryDate();
	public String getAccessory();
}
