package com.greatlearning.entity;

public class Employee {

	int id;
	String name;
	int age;
	int salary; // per annum
	String department;
	String city;

	public int getId() {

		if (id < 0) {
			System.out.println("Id cannot be negative");
			throw new IllegalArgumentException();
		}
		return id;
	}

	public void setId(int id) {

		if (id < 0) {
			System.out.println("Id cannot be negative");
			throw new IllegalArgumentException();
		}
		this.id = id;
	}

	public String getName() {
		if (name == null && name.isEmpty()) {
			System.out.println("Name cannot be null or empty");
			throw new IllegalArgumentException();
		}
		return name;
	}

	public void setName(String name) {
		if (name == null) {
			System.out.println("Name cannot be null or empty");
			throw new IllegalArgumentException();
		}
		this.name = name;
	}

	public int getAge() {
		if (age < 0) {
			System.out.println("age cannot be negative");
			throw new IllegalArgumentException();
		}
		return age;
	}

	public void setAge(int age) {
		if (age < 0) {
			System.out.println("age cannot be negative");
			throw new IllegalArgumentException();
		}
		this.age = age;
	}

	public int getSalary() {
		if (salary < 0) {
			System.out.println("salary cannot be negative");
			throw new IllegalArgumentException();
		}
		return salary;
	}

	public void setSalary(int salary) {
		if (salary < 0) {
			System.out.println("salary cannot be negative");
			throw new IllegalArgumentException();
		}
		this.salary = salary;
	}

	public String getDepartment() {
		if (department == null && department.isEmpty()) {
			System.out.println("department cannot be null or empty");
			throw new IllegalArgumentException();
		}
		return department;
	}

	public void setDepartment(String department) {
		if (department == null) {
			System.out.println("department cannot be null or empty");
			throw new IllegalArgumentException();
		}
		this.department = department;
	}

	public String getCity() {
		if (city == null && city.isEmpty()) {
			System.out.println("city cannot be null or empty");
			throw new IllegalArgumentException();
		}
		return city;
	}

	public void setCity(String city) {
		if (city == null) {
			System.out.println("city cannot be null or empty");
			throw new IllegalArgumentException();
		}
		this.city = city;
	}

}
