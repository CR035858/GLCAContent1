package com.greatlearning.driver;

import java.util.ArrayList;

import com.greatlearning.entity.Employee;
import com.greatlearning.service.LinkedListImplementation;
import com.greatlearning.service.TreeMapImplementation;

public class DriverClass {

	public static void main(String[] args) {

		ArrayList<Employee> employees = new ArrayList<>();

		Employee e1 = new Employee();
		e1.setId(1);
		e1.setName("Aman");
		e1.setAge(20);
		e1.setSalary(1100000);
		e1.setDepartment("IT");
		e1.setCity("Delhi");

		Employee e2 = new Employee();
		e2.setId(2);
		e2.setName("Bobby");
		e2.setAge(22);
		e2.setSalary(500000);
		e2.setDepartment("Hr");
		e2.setCity("Bombay");

		Employee e3 = new Employee();
		e3.setId(3);
		e3.setName("Zoe");
		e3.setAge(20);
		e3.setSalary(750000);
		e3.setDepartment("Admin");
		e3.setCity("Delhi");

		Employee e4 = new Employee();
		e4.setId(4);
		e4.setName("Smitha");
		e4.setAge(21);
		e4.setSalary(1000000);
		e4.setDepartment("IT");
		e4.setCity("Chennai");

		Employee e5 = new Employee();
		e5.setId(5);
		e5.setName("Smitha");
		e5.setAge(24);
		e5.setSalary(1200000);
		e5.setDepartment("Hr");
		e5.setCity("Bengaluru");

		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);

		System.out.println("List of employees");
		for (Employee emp : employees)
			System.out.println(emp.getId() + " " + emp.getName() + " " + emp.getAge() + " " + emp.getSalary() + " "
					+ emp.getDepartment() + " " + emp.getCity());
		

		LinkedListImplementation linkedListImplementation = new LinkedListImplementation();
		linkedListImplementation.sortingNames(employees);

		
		TreeMapImplementation treeMapImplementation = new TreeMapImplementation();
		treeMapImplementation.cityNameCount(employees);
		treeMapImplementation.monthlySalary(employees);

	}

}
