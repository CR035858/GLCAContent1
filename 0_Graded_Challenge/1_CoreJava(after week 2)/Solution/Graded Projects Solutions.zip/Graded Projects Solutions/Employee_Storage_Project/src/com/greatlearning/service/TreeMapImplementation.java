package com.greatlearning.service;

import java.util.ArrayList;
import java.util.TreeMap;

import com.greatlearning.entity.Employee;

public class TreeMapImplementation {

	public void cityNameCount(ArrayList<Employee> employees) {

		TreeMap<String, Integer> cityCount = new TreeMap<>();

		for (Employee emp : employees) {
			if (cityCount.containsKey(emp.getCity())) {
				int count = cityCount.get(emp.getCity());
				cityCount.replace(emp.getCity(), ++count);
			} else {
				cityCount.put(emp.getCity(), 1);
			}
		}
		System.out.println();
		System.out.println("Count of Employees from each city");
		System.out.println(cityCount);
	}

	public void monthlySalary(ArrayList<Employee> employees) {

		TreeMap<Integer, Double> monthlySalary = new TreeMap<>();

		try {
			for (Employee emp : employees) {
				monthlySalary.put(emp.getId(), (double) (emp.getSalary() / 12));
			}
			System.out.println();
			System.out.println("Monthly Salary of employee along with their id is");
			System.out.println(monthlySalary);
		} catch (ArithmeticException e) {
			System.out.println(e);
		}
	}
}
