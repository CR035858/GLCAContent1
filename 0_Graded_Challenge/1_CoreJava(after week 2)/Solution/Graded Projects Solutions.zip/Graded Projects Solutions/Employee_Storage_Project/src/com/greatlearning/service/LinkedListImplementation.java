package com.greatlearning.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import com.greatlearning.entity.Employee;

public class LinkedListImplementation {

	public void sortingNames(ArrayList<Employee> employees) {
		LinkedList<String> names = new LinkedList<String>();

		for (int i = 0; i < employees.size(); i++) {
			String name;
			name = employees.get(i).getName();
			names.add(name);
		}
		System.out.println();
		System.out.println("Names of all employees in the sorted order are ");
		Collections.sort(names);
		System.out.println(names);
	}
}
