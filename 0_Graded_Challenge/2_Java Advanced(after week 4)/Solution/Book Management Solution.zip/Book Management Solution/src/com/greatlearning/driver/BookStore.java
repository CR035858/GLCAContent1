package com.greatlearning.driver;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.greatlearning.util.Book;

public class BookStore {
	

	public static void main(String[] args) {
		
		// code to create book objects
		Book book1 = new Book(1,"To Kill a Mocking Bird", 200,"Classics");
		Book book2 = new Book(2,"Carrie",1000,"Horror");
		Book book3 = new Book(3,"The Savior",150,"Romance");
		Book book4 = new Book(4,"Wings of Fire", 250,"Autobiography");
		Book book5 = new Book(5,"Gandhi", 250,"Autobiography");
		Book book6 = new Book(6,"The Martian", 1000,"Sci-Fi");
		Book book7 = new Book(7,"Animal Farm", 200,"Political Satire");
		Book book8 = new Book(8,"Think and grow Rich", 500,"Self-Help");
		Book book9 = new Book(9,"Can't hurt me", 2000,"Motivational");
		Book book10 = new Book(10,"Getting things done", 350,"Self-Help");
		
		//code to add books to arrayList
		ArrayList<Book> books = new ArrayList<>();
		books.add(book1);
		books.add(book2);
		books.add(book3);
		books.add(book4);
		books.add(book5);
		books.add(book6);
		books.add(book7);
		books.add(book8);
		books.add(book9);
		books.add(book10);
		
		//code to print all the books in the library
		System.out.println("following books are currently present in the bookStore");
		System.out.println();
		books.forEach((book)->System.out.println("Id ->"+book.getId()+" "+"Name ->"+book.getName()+" "+"Price ->"+ book.getPrice() + " "+ "Genre ->"+book.getGenre()));
		System.out.println();
		
		
		//code to print the average price of all the books
		double average = books.stream().mapToDouble(book->book.getPrice()).average().getAsDouble();
		System.out.println("--------------------------------------------------------------------------");
        System.out.println("the average price of all the books in bookstore is --> "+ average);
        System.out.println();
        
        //code to print the total no of books present in the library
        long count = books.stream().count();
        System.out.println("total no of books in the library is --> " +count);
        
        //code to print the list of books which are in Autobiography genre
        System.out.println();
        System.out.println("Autobiographies --> "+books.stream().filter(book->book.getGenre().equals("Autobiography")).map(book->book.getName()).collect(Collectors.toList()));
      
        //code to print the count of distinct genres.
        System.out.println();
        List<String> genre = new ArrayList<>();
        genre = books.stream().map(book->book.getGenre()).collect(Collectors.toList());
        System.out.println("count of distinct genre is --> "+genre.stream().distinct().count());        
       
	}

}