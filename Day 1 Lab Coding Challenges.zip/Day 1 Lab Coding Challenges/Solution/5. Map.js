// 1. Square Numbers:
// Write a function that takes an array of numbers and uses the map method to create a new array containing the square of each number.

function squareNumbers(arr) {
    return arr.map((num) => num * num);
}

var numbers = [1, 2, 3, 4, 5];
console.log(squareNumbers(numbers)); // Output: [1, 4, 9, 16, 25]

// 2. Uppercase Transformation:
// Create a function that takes an array of strings and uses the map method to transform each string to uppercase. Return the modified array.

function uppercaseTransformation(arr) {
    return arr.map((str) => str.toUpperCase());
}

var words = ['apple', 'banana', 'kiwi'];
console.log(uppercaseTransformation(words)); // Output: ['APPLE', 'BANANA', 'KIWI']

// 3. Extract Lengths:
// Implement a function that takes an array of strings and uses the map method to create a new array containing the lengths of each string.

function extractLengths(arr) {
    return arr.map((str) => str.length);
}

var words = ['apple', 'banana', 'kiwi'];
console.log(extractLengths(words)); // Output: [5, 6, 4]

// 4. Add Prefix:
// Write a function that takes an array of words and a prefix string. Use the map method to add the prefix to each word. Return the modified array.

function addPrefix(arr, prefix) {
    return arr.map((word) => prefix + word);
}

var words = ['apple', 'banana', 'kiwi'];
console.log(addPrefix(words, 'fruit_')); // Output: ['fruit_apple', 'fruit_banana', 'fruit_kiwi']

// 5. Extract First Names:
// Given an array of objects with firstName and lastName properties, write a function that uses the map method to create a new array containing only the first names.

function extractFirstNames(arr) {
    return arr.map((obj) => obj.firstName);
}

var people = [
    { firstName: 'John', lastName: 'Doe' },
    { firstName: 'Jane', lastName: 'Doe' },
];
console.log(extractFirstNames(people)); // Output: ['John', 'Jane']

// 6. Calculate Areas:
// Create a function that takes an array of rectangles (objects with width and height properties) and uses the map method to calculate and return an array of their areas.

function calculateAreas(arr) {
    return arr.map((rectangle) => rectangle.width * rectangle.height);
}

var rectangles = [
    { width: 3, height: 5 },
    { width: 4, height: 8 },
];
console.log(calculateAreas(rectangles)); // Output: [15, 32]

// 7. Increment Values:
// Given an array of numbers, write a function that uses the map method to create a new array with each number incremented by a specified value.

function incrementValues(arr, incrementBy) {
    return arr.map((num) => num + incrementBy);
}

var numbers = [1, 2, 3, 4, 5];
console.log(incrementValues(numbers, 2)); // Output: [3, 4, 5, 6, 7]

// 8. Format Dates:
// Write a function that takes an array of date strings in a specific format and uses the map method to create a new array with the dates formatted differently.

function formatDates(arr) {
    return arr.map((dateString) => new Date(dateString).toDateString());
}

var dates = ['2022-01-01', '2022-02-15', '2022-03-20'];
console.log(formatDates(dates));
// Output: ['Fri Jan 01 2022', 'Tue Feb 15 2022', 'Sun Mar 20 2022']

// 9. Extract Initials:
// Implement a function that takes an array of names and uses the map method to create a new array containing the initials of each name.

function extractInitials(arr) {
    return arr.map((name) => name.split(' ').map((word) => word[0]).join(''));
}

var names = ['John Doe', 'Jane Smith', 'Alice Johnson'];
console.log(extractInitials(names)); // Output: ['JD', 'JS', 'AJ']

// 10. Convert Temperatures:
// Given an array of temperatures in Celsius, write a function that uses the map method to convert each temperature to Fahrenheit. Return the modified array.

function convertToCelsius(arr) {
    return arr.map((fahrenheit) => ((fahrenheit - 32) * 5) / 9);
}

var temperaturesInFahrenheit = [32, 68, 104];
console.log(convertToCelsius(temperaturesInFahrenheit)); // Output: [0, 20, 40]
