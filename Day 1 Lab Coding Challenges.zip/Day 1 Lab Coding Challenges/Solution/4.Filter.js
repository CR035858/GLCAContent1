// 1. Filter Even Numbers:
// Write a function that takes an array of numbers and uses the filter method to create a new array containing only the even numbers.

function filterEvenNumbers(arr) {
    return arr.filter((num) => num % 2 === 0);
}

var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
console.log(filterEvenNumbers(numbers)); // Output: [2, 4, 6, 8, 10]


// 2. Filter Words by Length:
// Implement a function that takes an array of strings and a length parameter. Use the filter method to create a new array containing only the strings with a length greater than or equal to the specified length.

function filterWordsByLength(arr, length) {
    return arr.filter((word) => word.length >= length);
}

var words = ['apple', 'banana', 'kiwi', 'orange', 'grape'];
console.log(filterWordsByLength(words, 5)); // Output: ['banana', 'orange']


// 3. Filter Positive Numbers:
// Write a function that takes an array of numbers and uses the filter method to create a new array containing only the positive numbers.

function filterPositiveNumbers(arr) {
    return arr.filter((num) => num > 0);
}

var numbers = [3, -5, 7, -2, 0, 8, -1];
console.log(filterPositiveNumbers(numbers)); // Output: [3, 7, 8]

// 4. Filter Names Starting with a Specific Letter:
// Create a function that takes an array of names and a target letter. Use the filter method to create a new array containing only the names that start with the specified letter.

function filterNamesByLetter(arr, letter) {
    return arr.filter((name) => name.charAt(0).toLowerCase() === letter.toLowerCase());
}

var names = ['Alice', 'Bob', 'Charlie', 'David'];
console.log(filterNamesByLetter(names, 'B')); // Output: ['Bob']

// 5. Filter Palindromes:
// Implement a function that takes an array of strings and uses the filter method to create a new array containing only the palindromes (words that read the same backward as forward).

function filterPalindromes(arr) {
    return arr.filter((word) => {
        var reversed = word.split('').reverse().join('');
        return word === reversed;
    });
}

var words = ['level', 'hello', 'radar', 'world'];
console.log(filterPalindromes(words)); // Output: ['level', 'radar']


// 6. Filter Objects by Property Value:
// Given an array of objects with a numeric property, write a function that uses the filter method to create a new array containing only the objects where the numeric property is greater than a specified value.

function filterObjectsByValue(arr, propertyName, threshold) {
    return arr.filter((obj) => obj[propertyName] > threshold);
}

var products = [
    { name: 'Laptop', price: 800 },
    { name: 'Phone', price: 600 },
    { name: 'Tablet', price: 300 },
  ];
  console.log(filterObjectsByValue(products, 'price', 500)); // Output: [{ name: 'Laptop', price: 800 }]
  
// 7. Filter Unique Elements:
// Create a function that takes an array and uses the filter method to create a new array containing only unique elements (no duplicates).

function filterUniqueElements(arr) {
    return arr.filter((value, index, self) => self.indexOf(value) === index);
}

var numbers = [1, 2, 3, 2, 4, 5, 3, 6];
console.log(filterUniqueElements(numbers)); // Output: [1, 2, 3, 4, 5, 6]

// 8. Filter Students by Grade:
// Given an array of student objects with a grade property, write a function that uses the filter method to create a new array containing only the students who have a grade above a certain threshold.

function filterStudentsByGrade(arr, threshold) {
    return arr.filter((student) => student.grade > threshold);
}

var students = [
    { name: 'Alice', grade: 85 },
    { name: 'Bob', grade: 92 },
    { name: 'Charlie', grade: 78 },
  ];
  console.log(filterStudentsByGrade(students, 90)); // Output: [{ name: 'Bob', grade: 92 }]
  
// 9. Filter by Category:
// Write a function that takes an array of objects with a category property and a target category. Use the filter method to create a new array containing only the objects with the specified category.

function filterByCategory(arr, targetCategory) {
    return arr.filter((item) => item.category === targetCategory);
}

var items = [
    { name: 'Book', category: 'Stationery' },
    { name: 'Laptop', category: 'Electronics' },
    { name: 'Backpack', category: 'Fashion' },
  ];
  console.log(filterByCategory(items, 'Electronics')); // Output: [{ name: 'Laptop', category: 'Electronics' }]
  
// 10. Filter Arrays of Arrays:
// Given an array of arrays, write a function that uses the filter method to create a new array containing only the arrays with a length greater than a specified value.

function filterArraysByLength(arr, length) {
    return arr.filter((innerArray) => innerArray.length > length);
}

var arrays = [[1, 2, 3], [4, 5], [6, 7, 8, 9]];
console.log(filterArraysByLength(arrays, 3)); // Output: [[6, 7, 8, 9]]
