// Question 1: Using the `apply` method, write a function that finds the maximum number in an array.

function findMaxNumber(numbers) {
  // Assume numbers is an array of numbers
  return Math.max.apply(null, numbers);
}

var numbers = [10, 5, 8, 20];
console.log(findMaxNumber(numbers)); // Output: 20

// Question 2: Write a function that concatenates two strings using the `bind` method.

function concatenateStrings(str1, str2) {
  return this + str1 + str2;
}

// Example usage
var greeting = "Hello, ";
var boundConcatenate = concatenateStrings.bind(greeting);
console.log(boundConcatenate("John", "!")); // Output: "Hello, John!"

// Question 3: Create a function that counts the number of properties in an object using `apply` and the `arguments` object.

function countProperties(obj) {
  return Object.keys(obj).length;
}

// Example usage
var person = {
  name: "John",
  age: 30,
  city: "New York",
};

console.log(countProperties.apply(null, [person])); // Output: 3

// Question 4: Write a function that accepts another function as an argument and returns a modified version of it that logs a message before and after executing the original function.

function modifyFunction(originalFunction) {
  return function () {
    console.log("Before executing the function");
    var result = originalFunction.apply(null, arguments);
    console.log("After executing the function");
    return result;
  };
}

// Example usage
function addNumbers(a, b) {
  return a + b;
}

var modifiedAddNumbers = modifyFunction(addNumbers);
console.log(modifiedAddNumbers(3, 5)); // Output: "Before executing the function", 8, "After executing the function"


// Question 5: Implement a function calculate that takes three arguments: a, b, and an operation function. The operation function should accept two parameters and perform a specific mathematical operation like addition, subtraction, multiplication and division. Use call(), apply(), or bind() to apply the operation function to the arguments a and b.


function calculate(a, b, operation) {
  return operation(a, b);
}

function addition(a, b) {
  return a + b;
}

function subtraction(a, b) {
  return a - b;
}

function multiplication(a, b) {
  return a * b;
}

function division(a, b) {
  return a / b;
}

console.log(calculate.call(3, 4, addition))   // Output: 7
console.log(calculate(5, 3, subtraction));    // Output: 2
console.log(calculate(5, 3, multiplication)); // Output: 15
console.log(calculate(5, 3, division));       // Output: 1.6666666666666667


// Question 6: Write a function printContext that, when invoked, logs the this keyword to the console. Then, demonstrate how the context of a function can change when calling it with different objects using the call method.

function printContext() {
  console.log(this);
}

var obj1 = { name: "Object 1" };
var obj2 = { name: "Object 2" };

printContext() // Output => Object [global] (This is representing the Window object)
printContext.call(obj1) // Output => { name: 'Object 1' }
printContext.call(obj2) // Output => { name: 'Object 2' }

// Question 7: Create a function “multiply” that takes two parameters and returns their product. Use the bind method to create a new function "double" that multiplies a single parameter by 2.


function multiply(x, y) {
  return x * y;
}

var double = multiply.bind(null, 2);
var result = double(5);
console.log(result); // Output: 10

// Question 8: Create an object person with properties name and age. Write a function "introduce" that logs a message introducing the person. Then, use the call method to invoke the introduce function with the person object as the context.


var person = {
  name: "John",
  age: 30
};

function introduce() {
  console.log(`Hi, I'm ${this.name} and I'm ${this.age} years old.`);
}

introduce.call(person); // Output: Hi, I'm John and I'm 30 years old.


