// Sum of Array Elements:
// 1. Write a function that takes an array of numbers and uses the forEach method to calculate the sum of all elements. Return the sum.

function sumArrayElements(arr) {
    var sum = 0;
    arr.forEach((num) => {
        sum += num;
    });
    return sum;
}


// Modify Array Elements:
// 2. Given an array of strings, use the forEach method to append "!" to each string. Return the modified array.

function appendExclamation(arr) {
    var modifiedArray = [];
    arr.forEach((str) => {
        modifiedArray.push(str + "!");
    });
    return modifiedArray;
}


// Find the Longest String:
// 3. Write a function that takes an array of strings and uses the forEach method to find the longest string. Return the longest string.

function findLongestString(arr) {
    var longest = "";
    arr.forEach((str) => {
        if (str.length > longest.length) {
            longest = str;
        }
    });
    return longest;
}

// Filter Odd Numbers:
// 4. Implement a function that takes an array of numbers and uses the forEach method to create a new array containing only the odd numbers.

function filterOddNumbers(arr) {
    var oddNumbers = [];
    arr.forEach((num) => {
        if (num % 2 !== 0) {
            oddNumbers.push(num);
        }
    });
    return oddNumbers;
}

// Counting Characters:
// 5. Create a function that takes an array of strings and uses the forEach method to count the total number of characters in all the strings. Return the count.

function countCharacters(arr) {
    var totalCount = 0;
    arr.forEach((str) => {
        totalCount += str.length;
    });
    return totalCount;
}

// Removing Duplicates:
// 6. Write a function that takes an array of numbers and uses the forEach method to create a new array without duplicate values.

function removeDuplicates(arr) {
    var uniqueArray = [];
    arr.forEach((num) => {
        if (!uniqueArray.includes(num)) {
            uniqueArray.push(num);
        }
    });
    return uniqueArray;
}

// Uppercase Transformation:
// 7. Given an array of strings, use the forEach method to transform each string to uppercase. Return the modified array.

function transformToUppercase(arr) {
    var uppercaseArray = [];
    arr.forEach((str) => {
        uppercaseArray.push(str.toUpperCase());
    });
    return uppercaseArray;
}

// Mapping to Object Properties:
// 8. Given an array of objects with name properties, use the forEach method to create a new array containing only the names. Return the new array.

function mapToObjectProperties(arr) {
    var namesArray = [];
    arr.forEach((obj) => {
        namesArray.push(obj.name);
    });
    return namesArray;
}

// Check for Even Numbers:
// 9. Implement a function that takes an array of numbers and uses the forEach method to check if all elements are even. Return a boolean.

function areAllEvenNumbers(arr) {
    var allEven = true;
    arr.forEach((num) => {
        if (num % 2 !== 0) {
            allEven = false;
        }
    });
    return allEven;
}

// Nested Arrays Sum:
// 10. Write a function that takes an array of arrays of numbers and uses forEach to calculate the sum of each inner array. Return an array of sums.

function sumOfInnerArrays(arr) {
    var sumsArray = [];
    arr.forEach((innerArray) => {
        var sum = 0;
        innerArray.forEach((num) => {
            sum += num;
        });
        sumsArray.push(sum);
    });
    return sumsArray;
}
