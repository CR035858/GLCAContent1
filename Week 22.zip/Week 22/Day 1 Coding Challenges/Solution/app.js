// ES6 Concepts: let, const, template strings, default arguments, array destructuring, object destructuring,
// rest and spread operators, defining a class in ES6

class TodoList {
    constructor() {
        this.tasks = [];
    }

    addTask(task) {
        this.tasks.push({ id: this.tasks.length + 1, task, completed: false });
    }

    completeTask(index) {
        if (index >= 0 && index < this.tasks.length) {
            this.tasks[index].completed = true;
        }
    }

    undoTask(index) {
        if (index >= 0 && index < this.tasks.length) {
            this.tasks[index].completed = false;
        }
    }
    getSummary() {
        const totalTasks = this.tasks.length;
        const completedTasks = this.tasks.filter(task => task.completed).length;
        const remainingTasks = totalTasks - completedTasks;
        return { totalTasks, completedTasks, remainingTasks };
    }
}

const todoList = new TodoList();

document.getElementById("addTaskBtn").addEventListener("click", function () {
    const taskInput = document.getElementById("taskInput");

    const task = taskInput.value.trim();
    if (task !== "") {
        todoList.addTask(task);
        updateTaskList();
        updateSummary();
        taskInput.value = "";
    }
});

function updateTaskList() {

    const taskList = document.getElementById("taskList");
    taskList.innerHTML = "";

        todoList.tasks.forEach((taskObj, index) => {
            const listItem = document.createElement("li");
            listItem.classList.add("taskItem");

            const taskTextElement = document.createElement("div");
            taskTextElement.classList.add("taskText");
            taskTextElement.textContent = taskObj.task;

            const toggleButton = document.createElement("button");
            toggleButton.classList.add("toggleButton");
            toggleButton.textContent = taskObj.completed ? "Undo" : "Done";
            
            if(toggleButton.textContent == "Undo") {
                listItem.classList.toggle("taskCompleted");
            }
            
            toggleButton.addEventListener("click", function () {
                // Toggle the "taskCompleted" class on the parent <li> element
                listItem.classList.toggle("taskCompleted");

                // Change the text content of the toggle button based on the state
                const isCompleted = listItem.classList.contains("taskCompleted");
                toggleButton.textContent = isCompleted ? "Undo" : "Done";

                if(isCompleted) {
                    todoList.completeTask(index)
                }
                else{
                    todoList.undoTask(index)
                }
                
                updateSummary();
            });

            listItem.appendChild(taskTextElement);
            listItem.appendChild(toggleButton);
            taskList.appendChild(listItem);

        });
}


function updateSummary() {
    const summary = todoList.getSummary();
    document.getElementById("totalTasks").textContent = summary.totalTasks;
    document.getElementById("completedTasks").textContent = summary.completedTasks;
    document.getElementById("remainingTasks").textContent = summary.remainingTasks;
}

updateSummary();
