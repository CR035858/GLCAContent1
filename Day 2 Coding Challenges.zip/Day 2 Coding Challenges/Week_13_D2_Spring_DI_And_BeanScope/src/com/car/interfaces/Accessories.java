package com.car.interfaces;

public interface Accessories {

	public String getFreeAccessory();
}
