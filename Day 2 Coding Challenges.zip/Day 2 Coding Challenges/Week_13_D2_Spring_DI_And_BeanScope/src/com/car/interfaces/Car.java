package com.car.interfaces;

import java.util.Date;

public interface Car {

	public String getSpecs();
	public String getPrice();
	public String deliveryDate();
	public String getAccessory();
}
