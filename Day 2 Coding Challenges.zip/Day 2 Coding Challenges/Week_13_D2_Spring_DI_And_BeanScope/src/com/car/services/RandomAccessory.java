package com.car.services;

import java.util.Random;

import com.car.interfaces.Accessories;

public class RandomAccessory implements Accessories{

	Product[] list = 	{
		new Product("Built in Umbrella", 2000),
		new Product("12V Vaccum Cleaner", 2500),
		new Product("Anti-Slip Foot Mat", 5000),
		new Product("Mobile Holder", 1750)
	};
			
	
	@Override
	public String getFreeAccessory() {
		
		Random ran = new Random();
		int index = ran.nextInt(list.length);
		Product randomProduct = list[index];
		
		return "Get "+randomProduct.name+" worth "+randomProduct.price+" for FREE!!!!";
	}

}
