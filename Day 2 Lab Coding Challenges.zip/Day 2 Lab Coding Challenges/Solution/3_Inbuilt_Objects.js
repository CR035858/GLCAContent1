// Global Object:
// Global Variables:
// 1. Write a function that declares a global variable and another function that attempts to access this variable from within a different scope. Discuss the outcome.

// Declare a global variable
var globalVariable = "I am a global variable";

function accessGlobalVariable() {
    // Access the global variable from within a different scope
    console.log(globalVariable);
}

// Call the function to demonstrate accessing the global variable
accessGlobalVariable();


// setTimeout with Global Function:
// 2. Use the setTimeout function to execute a global function after a certain delay. Explain the behavior of the global context.

// Define a global function
function globalFunction() {
    console.log("Executing global function after a delay");
}

// Use setTimeout to execute the global function after a delay of 2000 milliseconds (2 seconds)
setTimeout(globalFunction, 2000);


// Dialog Methods:
// Alert with User Input:
// 1. Create an alert dialog that prompts the user for their name and displays a personalized greeting using the entered name.

// Prompt the user for their name using an alert dialog
var userName = prompt("Please enter your name:");

// Display a personalized greeting using the entered name
alert("Hello, " + userName + "! Welcome!");


// Confirm and Conditional Action:
// 2. Use a confirm dialog to ask the user if they want to proceed with an action. Perform a specific action based on their choice.

// Ask the user if they want to proceed
var userChoice = confirm("Do you want to proceed with the action?");

// Perform a specific action based on the user's choice
if (userChoice) {
    console.log("User chose to proceed. Performing the action...");
} else {
    console.log("User chose not to proceed. Action canceled.");
}

// History Object:
// Navigate Back:
// 1. Write a function that uses the history object to navigate back to the previous page.

function navigateBack() {
    // Use the history object to navigate back to the previous page
    history.back();
}

// Call the function to demonstrate navigating back
navigateBack();

// Check History Length:
// 2. Implement a function that checks and logs the length of the user's browsing history.

function checkHistoryLength() {
    // Log the length of the user's browsing history
    console.log("Browsing history length: " + history.length);
}

// Call the function to demonstrate checking history length
checkHistoryLength();

// Navigator Object:
// Detect Browser:
// 1. Write a function that uses the navigator object to detect the user's browser and log a message accordingly.

function detectBrowser() {
    // Log a message based on the user's browser
    var browserMessage = navigator.userAgent.includes("Chrome")
        ? "You are using Chrome."
        : "You are using a browser other than Chrome.";
    console.log(browserMessage);
}

// Call the function to demonstrate detecting the browser
detectBrowser();

// Detect Online Status:
// 2. Implement a function that uses the navigator object to check if the user is currently online or offline.

function detectOnlineStatus() {
    // Check if the user is currently online or offline
    var onlineStatus = navigator.onLine ? "Online" : "Offline";
    console.log("You are currently " + onlineStatus);
}

// Call the function to demonstrate detecting online status
detectOnlineStatus();

// Location Object:
// Extract URL Parameters:
// 1. Create a function that extracts and logs the parameters from the current URL using the location object.

function extractURLParameters() {
    // Get the current URL
    var currentURL = location.href;

    // Extract and log the parameters from the current URL
    var urlParameters = new URLSearchParams(location.search);
    console.log("URL Parameters:", urlParameters.toString());
}

// Call the function to demonstrate extracting URL parameters
extractURLParameters();


// Modify URL and Reload:
// 2. Write a function that modifies the current URL by adding a query parameter. Reloading the page should reflect the change.

function modifyURLAndReload() {
    // Modify the current URL by adding a query parameter
    var newURL = location.href + "?modified=true";

    // Reload the page with the modified URL
    location.href = newURL;
}

// Call the function to demonstrate modifying the URL and reloading
modifyURLAndReload();
