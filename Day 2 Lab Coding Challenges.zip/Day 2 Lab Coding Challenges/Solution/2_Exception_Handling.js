// 1. Basic Exception Handling:
// Write a function that takes two numbers as parameters and returns their division. Implement exception handling to handle cases where the second number is zero.

function divideNumbers(a, b) {
    try {
        if (b === 0) {
            throw new Error('Division by zero is not allowed');
        }
        return a / b;
    } catch (error) {
        return `Error: ${error.message}`;
    }
}

var result = divideNumbers(10, 0);
console.log(result); // Output: Error: Division by zero is not allowed


// 2. Try-Catch-Finally:
// Write a function that attempts to open a file and read its contents. Implement a try-catch-finally block to handle any potential errors, and log appropriate messages in each block.

function readFromFile(filename) {
    try {
        // Attempt to open and read the file
        throw new Error('File not found');
    } catch (error) {
        console.log(`Error: ${error.message}`);
    } finally {
        console.log('Cleanup: Closing file connection');
    }
}

readFromFile('example.txt');


// 3. Chained Exceptions:
// Write a function that performs a series of operations on an array, such as sorting and filtering. Implement exception handling to catch errors at each step and provide meaningful error messages.

function arrayOperations(arr) {
    try {
        arr.sort();
        arr.filter(item => item > 0);
        // Perform other operations
    } catch (error) {
        console.log(`Error: ${error.message}`);
    }
}

var myArray = [3, -2, 5, 0];
arrayOperations(myArray);


// 4. Nested Try-Catch:
// Write a function that involves nested try-catch blocks. Demonstrate how inner catch blocks can handle exceptions without propagating them to the outer blocks.

function nestedTryCatch() {
    try {
        try {
            // Some operation that may throw an error
            throw new Error('Inner Error');
        } catch (innerError) {
            console.log(`Inner Catch: ${innerError.message}`);
        }

        // Continue with outer operation
        throw new Error('Outer Error');
    } catch (outerError) {
        console.log(`Outer Catch: ${outerError.message}`);
    }
}

nestedTryCatch();

// 5. Handling JSON Parsing Errors:
// Write a function that attempts to parse a JSON string. Implement exception handling to deal with cases where the provided string is not valid JSON.

function parseJSONString(jsonString) {
    try {
        var parsedData = JSON.parse(jsonString);
        return parsedData;
    } catch (error) {
        console.log(`JSON Parsing Error: ${error.message}`);
        return null;
    }
}

var invalidJSON = '{ name: "John", age: 30 }';
var result = parseJSONString(invalidJSON);

// 6. Handling Multiple Exception Types:
// Create a function that performs various operations on different data types. Implement exception handling to handle specific error types for each operation.

function performOperations(data) {
    try {
        // Operation 1: Division
        var result1 = data / 0;

        // Operation 2: Accessing undefined property
        var result2 = data.unknownProperty;

        // Operation 3: Invalid array access
        var result3 = data[10];

        return { result1, result2, result3 };
    } catch (error) {
        if (error instanceof TypeError) {
            console.log(`TypeError: ${error.message}`);
        } else if (error instanceof Error) {
            console.log(`Error: ${error.message}`);
        }
        return null;
    }
}

var testData = { value: 42 };
performOperations(testData);
