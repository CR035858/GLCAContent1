
// 1. Convert JSON to JavaScript object:

var jsonString1 = '{"name": "John", "age": 25, "city": "New York"}';
var jsonObj1 = JSON.parse(jsonString1);
console.log(jsonObj1);

// 2. Convert JavaScript object to JSON:

var jsonObj2 = { name: "John", age: 25, city: "New York" };
var jsonString2 = JSON.stringify(jsonObj2);
console.log(jsonString2);

// 3. Write JavaScript code to iterate over an array of JSON objects and extract a specific property from each object.

var jsonArray = [
  { name: "John", age: 30, city: "New York" },
  { name: "Alice", age: 25, city: "London" },
  { name: "Bob", age: 35, city: "Paris" }
];

jsonArray.forEach((obj) => {
  var name = obj.name;
  console.log(name);
});

// Access Nested Values:
// 4. Write a function that takes a nested JSON object and a key path (dot notation), and returns the corresponding value.

function accessNestedValue(jsonObject, keyPath) {
  const keys = keyPath.split('.');
  return keys.reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : undefined), jsonObject);
}

const nestedData = { person: { name: 'Bob', address: { city: 'Paris' } } };
const city = accessNestedValue(nestedData, 'person.address.city');
console.log(city);

// Modify JSON Object:
// 5. Given a JSON object, write a function to add or update a property with a new value.

function modifyJSONObject(jsonObject, key, value) {
  jsonObject[key] = value;
  return jsonObject;
}

let user = { name: 'Charlie', age: 28 };
user = modifyJSONObject(user, 'city', 'Berlin');
console.log(user);

// Filter JSON Array:
// 6. Given an array of JSON objects, write a function to filter objects based on a specific property value.

function filterJSONArray(jsonArray, propertyName, propertyValue) {
  return jsonArray.filter(item => item[propertyName] === propertyValue);
}

const users = [
  { id: 1, name: 'Alice', age: 30 },
  { id: 2, name: 'Bob', age: 25 },
  { id: 3, name: 'Charlie', age: 35 }
];

const filteredUsers = filterJSONArray(users, 'age', 30);
console.log(filteredUsers);


// Extras:
// 1. Given an array "students" of JSON objects define a function displayByKey which takes this array object and a keyName as string and displays the value of the key for each of the JSON objects.

// 2. Given an array, "students" of JSON objects write a code to iterate through each of these codes and extract the first name and last name of each student.

