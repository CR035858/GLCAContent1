// src/Poll.ts

export interface Poll {
  id: number;
  question: string;
  options: { option: string; votes: number }[];
}
