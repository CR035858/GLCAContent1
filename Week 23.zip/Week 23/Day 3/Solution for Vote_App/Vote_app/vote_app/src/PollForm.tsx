// src/PollForm.tsx

import React, { useState } from "react";
import { Poll } from "./Poll";

interface PollFormProps {
  onCreatePoll: (poll: Poll) => void;
}

const PollForm: React.FC<PollFormProps> = ({ onCreatePoll }) => {
  const [question, setQuestion] = useState<string>("");
  const [options, setOptions] = useState<string[]>(["", ""]);

  const handleQuestionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setQuestion(event.target.value);
  };

  const handleOptionChange = (
    index: number,
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newOptions = [...options];
    newOptions[index] = event.target.value;
    setOptions(newOptions);
  };

  const handleAddOption = () => {
    setOptions((prevOptions) => [...prevOptions, ""]);
  };

  const handleCreatePoll = () => {
    const poll: Poll = {
      id: Date.now(),
      question,
      options: options.map((option) => ({ option, votes: 0 })),
    };

    onCreatePoll(poll);

    // Reset form
    setQuestion("");
    setOptions(["", ""]);
  };

  return (
    <div>
      <h2>Create a Poll</h2>
      <label>Question:</label>
      <br></br>
      <input type="text" value={question} onChange={handleQuestionChange} />
      <br></br>
      <label>Options:</label>

      {options.map((option, index) => (
        <div key={index}>
          <input
            type="text"
            value={option}
            onChange={(e) => handleOptionChange(index, e)}
          />
        </div>
      ))}
      <br></br>
      <button onClick={handleAddOption}>Add Option</button>
      <button onClick={handleCreatePoll}>Create Poll</button>
    </div>
  );
};

export default PollForm;
