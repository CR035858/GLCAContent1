// src/App.tsx

import React, { useState } from "react";
import "./App.css";
import PollList from "./PollList";
import PollForm from "./PollForm";
import { Poll } from "./Poll";

const App: React.FC = () => {
  const [polls, setPolls] = useState<Poll[]>([]);

  const handleCreatePoll = (poll: Poll) => {
    setPolls((prevPolls) => [...prevPolls, poll]);
  };

  const handleVote = (pollId: number, optionIndex: number) => {
    setPolls((prevPolls) =>
      prevPolls.map((poll) =>
        poll.id === pollId
          ? {
              ...poll,
              options: poll.options.map((o, index) =>
                index === optionIndex ? { ...o, votes: o.votes + 1 } : o
              ),
            }
          : poll
      )
    );
  };

  return (
    <div className="App">
      <h1>Real-Time Polling App</h1>
      <PollList polls={polls} onVote={handleVote} />
      <PollForm onCreatePoll={handleCreatePoll} />
    </div>
  );
};

export default App;
