// src/PollList.tsx

import React, { useState, useEffect } from "react";
import { Poll } from "./Poll";

interface PollListProps {
  polls: Poll[];
  onVote: (pollId: number, optionIndex: number) => void;
}

const PollList: React.FC<PollListProps> = ({ polls, onVote }) => {
  return (
    <div>
      {polls.map((poll) => (
        <div key={poll.id}>
          <h3>{poll.question}</h3>
          <ul>
            {poll.options.map((option, index) => (
              <li key={index}>
                <button onClick={() => onVote(poll.id, index)}>
                  {option.option}
                </button>
                <span>Votes: {option.votes}</span>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default PollList;
