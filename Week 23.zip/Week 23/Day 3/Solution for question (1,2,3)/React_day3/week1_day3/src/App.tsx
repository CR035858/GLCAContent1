import React from "react";
import "./App.css";
import CombinedComponent from "./CombinedComponent";
import RegistrationForm from "./RegistrationForm";
import EducationForm from "./EducationForm";

const App: React.FC = () => {
  return (
    <div>
      <CombinedComponent message="Hello, this is a custom message!" />
      <RegistrationForm />
      <EducationForm />
    </div>
  );
};

export default App;
