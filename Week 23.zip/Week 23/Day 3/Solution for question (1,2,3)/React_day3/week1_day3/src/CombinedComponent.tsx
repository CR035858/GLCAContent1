import React, { useState } from "react";
import "./App.css"; // Import your CSS file for styling

interface CombinedComponentProps {
  message: string;
}

const CombinedComponent: React.FC<CombinedComponentProps> = ({ message }) => {
  const [inputValue, setInputValue] = useState<string>("");
  const [isHovered, setIsHovered] = useState<boolean>(false);

  const handleClick = () => {
    alert(message); // Trigger an alert with a custom message
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const boxStyle: React.CSSProperties = {
    width: "100px",
    height: "100px",
    backgroundColor: isHovered ? "lightblue" : "lightcoral",
  };

  return (
    <div>
      <div>
        <input type="text" value={inputValue} onChange={handleInputChange} />
        <p>Current value: {inputValue}</p>
      </div>

      <div
        style={boxStyle}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        Hover me!
      </div>
      <button onClick={handleClick}>Click Me</button>
    </div>
  );
};

export default CombinedComponent;
