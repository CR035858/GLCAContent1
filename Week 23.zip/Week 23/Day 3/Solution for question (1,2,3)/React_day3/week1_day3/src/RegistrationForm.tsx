import React, { useState } from "react";

const RegistrationForm: React.FC = () => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({
    username: "",
    email: "",
    password: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
    validateInput(name, value);
  };

  const validateInput = (name: string, value: string) => {
    switch (name) {
      case "username":
        setErrors((prevErrors) => ({
          ...prevErrors,
          username:
            value.length >= 3
              ? ""
              : "Username must be at least 3 characters long.",
        }));
        break;
      case "email":
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        setErrors((prevErrors) => ({
          ...prevErrors,
          email: emailRegex.test(value) ? "" : "Invalid email address.",
        }));
        break;
      case "password":
        setErrors((prevErrors) => ({
          ...prevErrors,
          password:
            value.length >= 6
              ? ""
              : "Password must be at least 6 characters long.",
        }));
        break;
      default:
        break;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Perform form submission logic here if needed
    alert("Form submitted:");
  };

  const isFormValid = Object.values(errors).every((error) => error === "");

  return (
    <div style={{ margin: "auto" }}>
      <h2>Registration Form</h2>
      <form onSubmit={handleSubmit}>
        <table>
          <tr>
            <td>
              <label>Username:</label>
            </td>
            <td>
              <input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
              />
            </td>
            <td>
              <span style={{ color: "red" }}>{errors.username}</span>
            </td>
          </tr>

          <tr>
            <td>
              <label>Email:</label>
            </td>
            <td>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </td>
            <td>
              <span style={{ color: "red" }}>{errors.email}</span>
            </td>
          </tr>

          <tr>
            <td>
              <label>Password:</label>
            </td>
            <td>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </td>
            <td>
              <span style={{ color: "red" }}>{errors.password}</span>
            </td>
          </tr>

          <tr>
            <td>
              <button type="submit" disabled={!isFormValid}>
                Register
              </button>
            </td>
          </tr>
        </table>
      </form>
    </div>
  );
};

export default RegistrationForm;
