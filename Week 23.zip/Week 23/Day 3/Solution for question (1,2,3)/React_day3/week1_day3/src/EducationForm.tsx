import React, { Component, createRef } from "react";

interface EducationEntry {
  school: string;
  degree: string;
  graduationYear: string;
}

interface UncontrolledEducationFormState {
  educationHistory: EducationEntry[];
}

class EducationForm extends Component<{}, UncontrolledEducationFormState> {
  private educationEntriesRef = createRef<HTMLInputElement[]>();

  constructor(props: {}) {
    super(props);

    this.state = {
      educationHistory: [{ school: "", degree: "", graduationYear: "" }],
    };
  }

  handleAddEducation = (): void => {
    this.setState((prevState) => ({
      educationHistory: [
        ...prevState.educationHistory,
        { school: "", degree: "", graduationYear: "" },
      ],
    }));
  };

  handleRemoveEducation = (index: number): void => {
    this.setState((prevState) => {
      const newEducationHistory = [...prevState.educationHistory];
      newEducationHistory.splice(index, 1);
      return { educationHistory: newEducationHistory };
    });
  };

  handleSubmit = (event: React.FormEvent): void => {
    event.preventDefault();

    // Filter out entries with empty school and degree fields
    const validEducationEntries = this.state.educationHistory.filter(
      (entry) => entry.school.trim() !== "" && entry.degree.trim() !== ""
    );

    // Display collected education history information
    console.log("Collected Education History:", validEducationEntries);
  };

  handleInputChange = (
    index: number,
    field: keyof EducationEntry,
    value: string
  ): void => {
    this.setState((prevState) => {
      const newEducationHistory = [...prevState.educationHistory];
      newEducationHistory[index][field] = value;
      return { educationHistory: newEducationHistory };
    });
  };

  render(): JSX.Element {
    const { educationHistory } = this.state;

    return (
      <div>
        <h2>Education History</h2>

        <form onSubmit={this.handleSubmit}>
          {educationHistory.map((entry, index: number) => (
            <div key={index}>
              <label>
                School:
                <input
                  type="text"
                  value={entry.school}
                  onChange={(e) =>
                    this.handleInputChange(index, "school", e.target.value)
                  }
                />
              </label>

              <label>
                Degree:
                <input
                  type="text"
                  value={entry.degree}
                  onChange={(e) =>
                    this.handleInputChange(index, "degree", e.target.value)
                  }
                />
              </label>

              <label>
                Graduation Year:
                <input
                  type="text"
                  value={entry.graduationYear}
                  onChange={(e) =>
                    this.handleInputChange(
                      index,
                      "graduationYear",
                      e.target.value
                    )
                  }
                />
              </label>

              <button
                type="button"
                onClick={() => this.handleRemoveEducation(index)}
              >
                Remove
              </button>
            </div>
          ))}

          <button type="button" onClick={this.handleAddEducation}>
            Add Education
          </button>

          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default EducationForm;
