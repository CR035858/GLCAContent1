import React, { Component, MouseEvent } from "react";

interface PersonProps {
  name?: string;
  age?: number;
  gender?: string;
}

interface PersonState {
  name: string;
  age: number;
  gender: string;
}

class Person extends Component<PersonProps, PersonState> {
  constructor(props: PersonProps) {
    super(props);

    // Initialize state with name, age, and gender derived from props
    this.state = {
      name: props.name || "Unknown",
      age: props.age || 0,
      gender: props.gender || "Unknown",
    };
  }

  handleAgeIncrement = () => {
    // Increment the age by 1 when the button is clicked
    this.setState((prevState) => ({ age: prevState.age + 1 }));
  };

  render() {
    const { name, age, gender } = this.state;

    return (
      <div>
        <h2>Person Information</h2>
        <p>Name: {name}</p>
        <p>Age: {age}</p>
        <p>Gender: {gender}</p>
        <button onClick={this.handleAgeIncrement}>Increment Age</button>
      </div>
    );
  }
}

export default Person;
