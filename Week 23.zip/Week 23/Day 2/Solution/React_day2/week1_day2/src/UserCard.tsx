import React from "react";

interface UserCardProps {
  username: string;
  email: string;
  avatar: string;
}

const UserCard: React.FC<UserCardProps> = (props) => {
  const { username, email, avatar } = props;

  return (
    <div
      style={{
        border: "1px solid #ccc",
        padding: "10px",
        borderRadius: "8px",
        margin: "10px",
        width: "200px",
      }}
    >
      <img
        src={avatar}
        alt={`${username}'s Avatar`}
        style={{ width: "100%", borderRadius: "50%" }}
      />
      <h3>{username}</h3>
      <p>{email}</p>
    </div>
  );
};

export default UserCard;
