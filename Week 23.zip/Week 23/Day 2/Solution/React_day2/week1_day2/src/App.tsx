import "./App.css";
import ColorChanger from "./ColorChanger";
import CounterApp from "./CounterApp";
import TodoListApp from "./TodoListApp";
import GreetingComponent from "./GreetingComponent";
import UserCard from "./UserCard";
import WeatherDisplay from "./WeatherDisplay";
import Person from "./Person";

function App() {
  const user1 = {
    username: "john_doe",
    email: "john.doe@example.com",
    avatar: "https://example.com/john_avatar.jpg",
  };

  const user2 = {
    username: "jane_smith",
    email: "jane.smith@example.com",
    avatar: "https://example.com/jane_avatar.jpg",
  };

  return (
    <div>
      <ColorChanger />
      <CounterApp />
      <TodoListApp />
      <GreetingComponent name={"Riya"} />
      <h1>User Cards</h1>
      <UserCard {...user1} />
      <UserCard {...user2} />
      <h1>Weather App</h1>
      <WeatherDisplay temperature={5} />
      <WeatherDisplay temperature={20} />
      <WeatherDisplay temperature={30} />
      <Person name="John" age={25} gender="Male" />
    </div>
  );
}

export default App;
