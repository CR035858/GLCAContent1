import React, { useState } from "react";

const ColorChanger: React.FC = () => {
  // Array of colors to cycle through
  const colors: string[] = ["red", "blue", "green", "yellow", "purple"];

  // State to manage the current color index
  const [currentColorIndex, setCurrentColorIndex] = useState<number>(0);

  // Function to handle the button click and cycle through colors
  const handleChangeColor = () => {
    // Increment the color index, and loop back to the beginning if it exceeds the array length
    setCurrentColorIndex((prevIndex) => (prevIndex + 1) % colors.length);
  };

  return (
    <div>
      <h1 style={{ color: colors[currentColorIndex] }}>Color Changer App</h1>
      <button onClick={handleChangeColor}>Change Color</button>
    </div>
  );
};

export default ColorChanger;
