import React from "react";

interface GreetingComponentProps {
  name: string;
}

const GreetingComponent: React.FC<GreetingComponentProps> = ({ name }) => {
  // Check if the 'name' prop is provided and is a string
  if (!name || typeof name !== "string") {
    console.error(
      "Error: 'name' prop must be a string and should be provided."
    );
    // You may choose to return null or handle the missing/invalid prop differently
    return null;
  }

  return (
    <div>
      <h1>Hello, {name}!</h1>
    </div>
  );
};

export default GreetingComponent;
