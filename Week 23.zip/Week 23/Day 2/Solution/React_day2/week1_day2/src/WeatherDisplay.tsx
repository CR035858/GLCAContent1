import React from "react";

interface WeatherDisplayProps {
  temperature: number;
}

const WeatherDisplay: React.FC<WeatherDisplayProps> = ({ temperature }) => {
  let message;

  if (temperature < 10) {
    message = "It's cold!";
  } else if (temperature >= 10 && temperature <= 25) {
    message = "It's warm!";
  } else {
    message = "It's hot!";
  }

  return (
    <div>
      <p>{message}</p>
    </div>
  );
};

export default WeatherDisplay;
