import React, { useState } from "react";

const CounterApp: React.FC = () => {
  // State to store the counter value
  const [counter, setCounter] = useState<number>(0);

  // Function to handle incrementing the counter
  const handleIncrement = () => {
    setCounter((prevCounter) => prevCounter + 1);
  };

  // Function to handle decrementing the counter
  const handleDecrement = () => {
    setCounter((prevCounter) => prevCounter - 1);
  };

  return (
    <div>
      <h1>Counter: {counter}</h1>
      <button onClick={handleIncrement}>ENTRY</button>
      <button onClick={handleDecrement}>EXIT</button>
    </div>
  );
};

export default CounterApp;
