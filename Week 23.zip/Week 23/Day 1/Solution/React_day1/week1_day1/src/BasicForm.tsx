import React from "react";
import "./BasicForm.css"; // Import your CSS file (adjust the path based on your project structure)

const BasicForm = () => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Add your form submission logic here
    console.log("Form submitted!");
  };

  return (
    <div className="form-container">
      <h2>Basic Form</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="firstName">First Name:</label>
        <input type="text" id="firstName" name="firstName" />

        <label htmlFor="lastName">Last Name:</label>
        <input type="text" id="lastName" name="lastName" />

        <label htmlFor="email">Email:</label>
        <input type="email" id="email" name="email" />

        <label htmlFor="phno">Phone No:</label>
        <input type="number" id="phno" name="phno" />

        <label htmlFor="addr">Address:</label>
        <input type="text" id="addr" name="addr" />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default BasicForm;
