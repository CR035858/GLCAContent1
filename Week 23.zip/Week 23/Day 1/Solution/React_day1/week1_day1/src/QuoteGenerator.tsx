import React, { Component } from "react";
import "./QuoteGenerator.css"; // Import your CSS file (adjust the path based on your project structure)

class QuoteGenerator extends Component {
  quotes: string[] = [
    "The only limit to our realization of tomorrow will be our doubts of today.",
    "Do not wait to strike till the iron is hot, but make it hot by striking.",
    "It's not whether you get knocked down, it's whether you get up.",
    "The future belongs to those who believe in the beauty of their dreams.",
    "Believe you can and you're halfway there.",
    "Success is not final, failure is not fatal: It is the courage to continue that counts.",
  ];

  generateQuote = () => {
    const quoteElement = document.getElementById("quote") as HTMLQuoteElement;
    const randomIndex = Math.floor(Math.random() * this.quotes.length);
    const randomQuote = this.quotes[randomIndex];
    quoteElement.textContent = randomQuote;
  };

  render() {
    return (
      <div className="quote-generator">
        <h1>Inspiration for the Day</h1>
        <blockquote id="quote"></blockquote>
        <button onClick={this.generateQuote}>Generate Quote</button>
      </div>
    );
  }
}

export default QuoteGenerator;
