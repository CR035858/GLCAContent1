import React from "react";

const Function_helloworld: React.FC = () => {
  return (
    <div>
      <h1>Hello World from Functional Component</h1>
    </div>
  );
};

export default Function_helloworld;
