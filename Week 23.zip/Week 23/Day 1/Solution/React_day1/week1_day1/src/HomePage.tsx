import React, { Component } from "react";
import "./HomePage.css"; // Import your CSS file (adjust the path based on your project structure)

class HomePage extends Component {
  render(): JSX.Element {
    return (
      <div>
        <header className="header">
          <h1>My React App</h1>
        </header>

        <nav className="navbar">
          <ul className="nav-list">
            <li>
              <a href="#">Home</a>
            </li>
            <li>
              <a href="#">About</a>
            </li>
            <li>
              <a href="#">Services</a>
            </li>
            <li>
              <a href="#">Contact</a>
            </li>
          </ul>
        </nav>

        <main className="content">
          <h2>Welcome to My React App</h2>
          <p>
            This is a basic home page with a header, navigation bar, content,
            and a footer.
          </p>
        </main>

        <footer className="footer">
          <p>&copy; 2023 My React App. All rights reserved.</p>
        </footer>
      </div>
    );
  }
}

export default HomePage;
