import React from "react";
import "./App.css";
import Class_helloworld from "./Class_helloworld";
import Function_helloworld from "./Function_helloworld";
import BasicForm from "./BasicForm";
import HomePage from "./HomePage";
import QuoteGenerator from "./QuoteGenerator";

function App() {
  return (
    <div>
      <HomePage />
      <Class_helloworld />
      <hr></hr>
      <Function_helloworld />
      <BasicForm />
      <QuoteGenerator />
    </div>
  );
}

export default App;
