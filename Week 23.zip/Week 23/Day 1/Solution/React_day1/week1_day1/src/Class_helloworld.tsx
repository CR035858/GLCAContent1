import React, { Component } from "react";

class Class_helloworld extends Component {
  private greeting: string = "Hello World from Class Component";

  render() {
    return (
      <div>
        <h1>{this.greeting}</h1>
      </div>
    );
  }
}

export default Class_helloworld;
