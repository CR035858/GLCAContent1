package com.greatlearning.floydTriangle;


//Main class
class FloydTriangle {

	// Main driver method
	public static void main(String[] args) {
		// No of rows to be printed
		int noOfRows = 4;

		
		int row, column, value = 1;

		
		// Outer loop for rows
		for (row = 1; row <= noOfRows; row++) {

			// Inner loop for columns
			for (column = 1; column <= row; column++) {

				// Printing value to be displayed
				System.out.print(value + " ");

				// Incremeting value displayed
				value++;
			}

			// Print elements of next row
			System.out.println();
		}
	}
}
