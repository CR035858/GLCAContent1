package com.greatlearning.arraySumAvg;

import java.util.Scanner;

public class Sum_Average {
	public static void main(String[] args) {
		
		int size, sum = 0;
		float average;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array:");
		size = sc.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter all the elements:");
		for (int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
			sum = sum + arr[i];
		}
		System.out.println("Sum:" + sum);
		average = (float) sum /size;
		System.out.println("Average:" + average);
		sc.close();
	}
}